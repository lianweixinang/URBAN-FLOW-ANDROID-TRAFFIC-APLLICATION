package ntutifm.game.google.entity

data class SearchData(val title : String , val logo : Int)